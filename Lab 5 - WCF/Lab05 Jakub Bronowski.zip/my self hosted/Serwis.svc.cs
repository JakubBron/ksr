﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Web;

using KSR_WCF2;

namespace my_self_hosted
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    // CMD: test.exe http://localhost:1998/Serwis.svc/zad5 http://localhost:1998/Serwis.svc/zad6
    public class Serwis : IZadanie5, IZadanie6
    {
        public void Dodaj(int a, int b)
        {
            var channel = OperationContext.Current.GetCallbackChannel<IZadanie6Zwrotny>();
            channel.Wynik(a + b);
        }

        public string ScalNapisy(string a, string b)
        {
            return a + b;
        }
    }
}
